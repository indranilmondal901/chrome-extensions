// chrome.runtime.onInstalled.addListener(function () {
//     // Add event listener to listen for clicks on the webpage
//     chrome.tabs.onActivated.addListener(function (activeInfo) {
//       chrome.tabs.get(activeInfo.tabId, function (tab) {
//         chrome.scripting.executeScript({
//           target: { tabId: tab.id },
//           function: handleColorPick,
//         });
//       });
//     });
//   });
  
//   function handleColorPick() {
//     console.log("here");
//     document.addEventListener('click', function (event) {
//       // Get the color of the clicked element
//       const clickedElement = event.target;
//       const computedStyles = window.getComputedStyle(clickedElement);
//       const bgColor = computedStyles.getPropertyValue('background-color');
  
//       // Send message to the popup with the color code
//       chrome.runtime.sendMessage({ colorCode: bgColor });
//     });
//   }

export const ColorPickerWorker = async () => {
  console.log("here in background.js")
};