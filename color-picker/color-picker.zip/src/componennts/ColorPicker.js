/* global chrome */
import React, { useState, useEffect } from 'react';
import { ColorPickerWorker } from '../background';


function ColorPicker() {
  const [colorCode, setColorCode] = useState(null);

  useEffect(() => {
    // Add event listener to listen for messages from background script
    chrome.runtime.onMessage.addListener(function (message) {
      setColorCode(message.colorCode);
    });
  }, []);

  const handleColorPicker = () =>{
    ColorPickerWorker();
  }

  return (
    <div>
      <h1>Color Picker</h1>
      <button onClick={()=>handleColorPicker()}>
        Pick Color
      </button>
      {colorCode && <p>Selected Color: {colorCode}</p>}
    </div>
  );
}

export default ColorPicker;
