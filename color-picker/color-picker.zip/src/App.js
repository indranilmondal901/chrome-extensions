import './App.css';
import ColorPicker from './componennts/ColorPicker';

function App() {
  return (
    <>
      <ColorPicker/>
    </>
  );
}

export default App;
